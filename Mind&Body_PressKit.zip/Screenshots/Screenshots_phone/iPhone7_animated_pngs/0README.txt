Note:
You can take out/separate the individual images that make up the animated pngs and use them as simple pngs.
On a mac, open the apng with preview and drag out the simple images you want.

These apngs are used on the website: mind-and-body.info
